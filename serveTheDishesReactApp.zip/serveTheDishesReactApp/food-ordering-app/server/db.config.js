const dbName = 'food-ordering';
const dbHost = 'localhost';
const dbPort = 27017;
module.exports = {
    // url: `mongodb://${dbHost}:${dbPort}/${dbName}`
    url: `mongodb+srv://admin:admin@cluster0.ingvzrv.mongodb.net/food-ordering?retryWrites=true&w=majority`
}