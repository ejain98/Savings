import aboutImage from "../assets/images/about-image.png";

export const About = () => {

    return (
        <div id="about" className="bg-white">
            <div className="p-24 grid grid-cols-2">
                <div className="">
                    <h2 className="text-2xl font-medium">About Us</h2>
                    <p className="text-lg">
                    The company itself is a very successful company. fall
                     happy! The flight of pains opens the door to great pleasures
                     therefore error, and practice, flees from such ways as pleasures
                     follow him! Of course! Lorem ipsum dolor sit amet, consectetur
                     adipisicing elit. Less because he takes leave, and no one forgives
                     obtain the softened guilt, pain, all pains, to assume the matter of truth
                     and the most worthy of them, for you will never owe them!
                    </p>
                </div>
                <div className="flex items-center justify-center">
                    <img src={aboutImage} alt="" className="w-[400px] h-[400px] object-cover" />
                </div>
            </div>
        </div>
    )
}