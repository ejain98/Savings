
import React , {useState,useEffect} from 'react';

import { CssBaseline, Grid } from '@material-ui/core';
import {getPlacesData} from './api';
import Header from './components/Header/header';
import List from './components/List/list';
import Map from './components/Map/map';
import PlaceDetails from './components/PlaceDetails/placeDetails';


function App() {

  const [places , setPlaces] = useState([])
  const [childClicked, setChildClicked] = useState({});

  const [filteredPlaces, setFilteredPlaces] = useState({});

  const [coordinates , setCoordinates] = useState({});
  const [bounds, setBounds] = useState({});
  const [isLoading, setIsLoading] = useState(false);

  const [rating, setRating] = useState('rating');


  useEffect(() => {

    navigator.geolocation.getCurrentPosition(({ coords: { latitude, longitude } }) => {
      setCoordinates({ lat: latitude, lng: longitude });

    });

  }, []);

  useEffect(()=>{
    const filteredPlaces = places.filter((place)=>place.rating>rating);

    setFilteredPlaces(filteredPlaces);

  },[rating]);
  
  useEffect(()=>{

    if(bounds.sw && bounds.ne){

    setIsLoading(true);
 getPlacesData(bounds.sw, bounds.ne)
       .then((data)=>{
         console.log(data);
          setPlaces(data?.filter((place)=> place.name && place.num_reviews > 0));
          setFilteredPlaces([])
          setIsLoading(false);
          })
        }

  }, [ bounds]);
  return (
    <>
      <CssBaseline />
      <Header  setCoordinates= {setCoordinates}/>
      <Grid container spacing={3} style={{ width: '100%' }}>
        <Grid item xs={12} md={4}>
          <List  places = {filteredPlaces.length? filteredPlaces:  places}
                childClicked = {childClicked}
                isLoading = {isLoading}
                rating = {rating}
                setRating = {setRating}

          
          />
        </Grid>
        <Grid item xs={12} md={8} style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
          {<Map
            setCoordinates = {setCoordinates}
            setBounds = {setBounds}
            coordinates = {coordinates}
            places={filteredPlaces.length? filteredPlaces:  places }
            setChildClicked={setChildClicked}
          
          /> }
         
        </Grid>
      </Grid>
    </>
  );
}

export default App;
