import { useLocation } from 'react-router-dom';
import { deliveryModes } from '../constants';
import './styles.css';

function Delivery({data}) {
	const location = useLocation();
  	
	return (
		<div className="right">
			<h2>{deliveryModes[location.pathname.substring(1)]} Deliveries: </h2>
			{data.map((o,i) => {
				return(
					<div  key={i}>
						<h5>Order {i+1}: {o.status || ""}</h5>
						<ul>
							<li>{o.items.join(", ")}</li>
							<li>${o.amount}</li>
							<li>{o.distance}</li>
							<li>{o.time}</li>
						</ul>
						<hr />
					</div>
				)
			})}
		</div>
	);
}

export default Delivery;
