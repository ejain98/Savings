import { useState } from 'react';
import { Link } from 'react-router-dom';
import { deliveryStatus } from '../constants';
import './styles.css';

function Menu({data}) {
    const [showSummary,setShowSummary] = useState(false);
    const [amountSummary] = useState(data.reduce(
        (a,b) => b.status === deliveryStatus.completed ? a += b.amount : null)
      );

    return (
        <div className="left">
            <div className="overlay">
                <div className="btn">
                    <Link className="button" to="/current">Current Delivery</Link>
                    <Link className="button" to="/available">Available Delivery</Link>
                    <a  className="button pointer" style={showSummary ? {
                            backgroundColor: 'rgb(226, 62, 48)',
                            color: 'white'
                        } : {}}
                        onClick={() => setShowSummary(!showSummary)}>{showSummary ? "Hide" : "Amount"} Summary</a>
                    {
                        showSummary &&
                        <div id="amount" className='summary'>
                            So far, you have earned ${amountSummary.toFixed(2)}  with us. 
                            <Link to='/'>Details</Link>
                            <hr />
                        </div>
                    }
                </div>
            </div>
        </div>
    );
    }

export default Menu;
