exports.deliveryModes = {
    "available": "Available",
    "current": "Current"
}

exports.deliveryStatus = {
    "completed": "Completed",
    "pending": "Pending"
}