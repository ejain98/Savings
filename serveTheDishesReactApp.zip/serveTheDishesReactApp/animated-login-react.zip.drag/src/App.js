import React, { useState } from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate
} from "react-router-dom";
import "./App.css";
import Delivery from "./components/Delivery";
import Menu from "./components/Menu";
import sample from './assets/sample';
  
function App() {
  const [currentDelivery] = useState(sample.currentDelivery);
  const [availableDelivery] = useState(sample.availableDelivery);

  return (
    <div className="boxform">
      <Router>
        <Menu data={currentDelivery} />
        <Routes>
          <Route  path="/current" 
                  element={
                    <Delivery data={currentDelivery} />
                  } 
          />
          <Route  path="/available" 
                  element={
                    <Delivery data={availableDelivery} />
                  } 
          />
          <Route path="*" element={<Navigate replace to="/current" />} />
        </Routes>
      </Router>
    </div>
  );
}
  
export default App;