const { deliveryStatus } = require("../constants");

exports.currentDelivery = [
    {
        items: ["Chocolate Truffle", "Mousse Cake"],
        amount: 15.5,
        distance: "5 KM",
        time: "28 mins",
        status: deliveryStatus.pending
    },
    {
        items: ["Potatoes Dauphinoise"],
        amount: 35.99,
        distance: "12 KM",
        time: "48 mins",
        status: deliveryStatus.pending
    },
    {
        items: ["Confit de canard","Chocolate soufflé","Cassoulet"],
        amount: 75,
        distance: "8 KM",
        time: "35 mins",
        status: deliveryStatus.completed
    },
    {
        items: ["Bistecca Alla Fiorentina"],
        amount: 18.35,
        distance: "3 KM",
        time: "15 mins",
        status: deliveryStatus.completed
    },
    {
        items: ["Lasagne","Ravioli"],
        amount: 22.82,
        distance: "12 KM",
        time: "23 mins",
        status: deliveryStatus.completed
    }
]

exports.availableDelivery = [
    {
        items: ["Butter tarts","Peameal Bacon"],
        amount: 20.11,
        distance: "4 KM",
        time: "25 mins"
    },
    {
        items: ["Nova Scotian Lobster Rolls"],
        amount: 24.99,
        distance: "8 KM",
        time: "25 mins"
    },
    {
        items: ["Käsespätzle","Schnitzel"],
        amount: 45.22,
        distance: "12 KM",
        time: "45 mins"
    },
    {
        items: ["Sauerbraten"],
        amount: 12.78,
        distance: "2 KM",
        time: "15 mins"
    },
    {
        items: ["Tandoori Chicken"],
        amount: 28.55,
        distance: "5 KM",
        time: "20 mins"
    },
    {
        items: ["Biryani","Naan"],
        amount: 22.99,
        distance: "8 KM",
        time: "32 mins"
    }
]